
import React, { Component } from 'react';
import { Button } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import AdminNavbar from './AdminNavbar';
import UserNavbar from './UserNavbar';

class AdminHome extends Component {
    constructor(props) {
        super(props)
        if (!sessionStorage.getItem("adminLogged"))
            props.history.push("/")
    }
    render() {
        return (
            <>
            <AdminNavbar 
              logOut={this.logOut}
            />          
            <div className="text-white text-center pt-5">
                welcome to  admin page <br />

            </div>
            </>
        );
    }
}
export default AdminHome;