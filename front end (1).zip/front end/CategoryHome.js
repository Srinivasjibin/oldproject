import react, { Component } from 'react'
import { Button, Container, Form, Row, Nav,Accordion,Card } from 'react-bootstrap';
import { Link } from 'react-router-dom';
import axios from 'axios'
import CatRepNavBar from './CatRepNavBar';

export default class CategoryHome extends Component {
    constructor(props) {
        super(props);
        this.state={
            data:[],
            username:sessionStorage.getItem("username")
        }
        if (!sessionStorage.getItem("categoryRepLogged")){
            window.alert("you have logged out! login to continue")
            this.props.history.push("/")
        }
            
    }
    componentDidMount(){
        axios.get('http://localhost:8080/api/admin/getIssueHistory')           
            .then(response => {
                this.setState({ data: response.data })
            }).catch(error=>console.log("history error",error))
    }
    render() {
        return (
            <>
            <CatRepNavBar />
            <Container>
                
                <div className="my-5 mx-auto">
                <h5 className="text-danger">Reopened Issues</h5>
                {this.state.data.filter(data=>data.issueStatus=="reopened"&&data.issueCategory==sessionStorage.category).map((el, idx) => {
                    return <div>
                        <Accordion >
                            <Card className="bg-dark" >
                                <Card.Header>
                                    <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                        <h5>Notification {idx + 1}</h5>
                                    </Accordion.Toggle>
                                </Card.Header>
                                <Accordion.Collapse eventKey="0">
                                    <Card.Body> <div>
                                        <h5 className="text-light">Issue name:{<br />}<span className="p-2 text-danger">{el.issueName}</span></h5>
                                        <p className="text-light">Issue Description :{<br />}<span className="text-warning">{el.issueDescription}</span></p>
                                        <p className="text-light">Issue Resolution :{<br />}<span className="text-warning">{el.issueResolution}</span></p>
                                        <p className="text-light">Issue Category:{<br />}<span className="text-warning">{el.issueCategory}</span></p>
                                        <p className="text-light">Issue Created On :{<br />}<span className="text-warning">{el.issueDate}</span></p>
                                        <p className="text-light">User Comments :{<br />}<span className="text-warning">{el.userComments}</span></p>
                                    </div></Card.Body>
                                </Accordion.Collapse>
                            </Card>
                        </Accordion>
                    </div>
                })}
                </div>
            </Container>
            </>
        )
    }
}