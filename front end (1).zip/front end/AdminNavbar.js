import react, { Component } from 'react'
import { Button, Container, Form, Row, Nav } from 'react-bootstrap';
export default class AdminNavbar extends Component {
  constructor(props) {
    super(props)

  }
  logOut = () => {
    sessionStorage.removeItem("adminLogged");
    window.alert("logged out successfully! ")
    window.location.href = ("/")
  }
  render() {

    return (
      <Nav className="mx-auto navbar bg-dark border border-warning pad">
        <Nav.Item >
          <Nav.Link href="/adminHome">Home</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href="/admin/addCategory">Add Catagory</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href="/admin/viewCategory">View Catagory</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href="/admin/viewHistory">View History</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link onClick={this.logOut}>Log Out</Nav.Link>
        </Nav.Item>
      </Nav>
    )
  }
}