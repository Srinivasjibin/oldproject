import React, { Component } from "react";
import { Container } from 'react-bootstrap';

import axios from 'axios';
import AdminNavbar from "./AdminNavbar";

export default class AdminCatagoryUpdate extends Component {
    constructor(props) {
        super(props);
        if (!sessionStorage.getItem("adminLogged"))
            props.history.push("/")
        this.state = {
            "categoryId": sessionStorage.getItem("selectedId"),
            "categoryType": '',
            "categoryDescription": ''
        }
    }
    componentWillMount() {
        console.log(this.state.categoryId)
        axios.get("http://localhost:8080/api/admin/getCategoryById/" + this.state.categoryId
        ).then(response =>
            this.setState({
                categoryType: response.data.categoryType,
                categoryDescription: response.data.categoryDescription
            })
        ).catch(err => console.log(err))
    }
    changeHandler = (event) => {
        this.setState({
            [event.target.name] : event.target.value
        })
    }
    updateHandler = (event) => {
        axios.put("http://localhost:8080/api/admin/updateCategory", {
            "categoryId":this.state.categoryId,
            "categoryType": this.state.categoryType,
            "categoryDescription": this.state.categoryDescription
        }).then(res=>{
            console.log("@rsponse ",res)
            window.alert("category updated")
            window.location.href=("viewCategory")
        })
        event.preventDefault();
    }
    deleteHandler = () => {
        axios.delete("http://localhost:8080/api/admin/deleteCategory/"+this.state.categoryId)
        .then(res=>{
            console.log("@rsponse ",res)
            window.alert("category deleted")
            window.location.href=("viewCategory")
        })
    }
    render() {
        console.log(this.state)
        return (
            <div>
                <AdminNavbar />
                <Container> <br />
                    <form className="text-warning mt-5 col-7" onSubmit={this.updateHandler}>
                        <label>Catagory type</label>
                        <input type="text" placeholder="Enter Catagory type" className="form-control " required name='categoryType' value={this.state.categoryType} onChange={this.changeHandler} /><br />
                        <label>Catagory Description</label>
                        <textarea type="textarea" rows={3} className="form-control" required placeholder="Enter Catagory Description" name='categoryDescription' value={this.state.categoryDescription} onChange={this.changeHandler} /><br />
                        <input className="bg-primary rounded border border-warning mr-5" type="submit" value="update" />
                        <input className="bg-primary rounded border border-warning ml-5" type="button" value="delete" onClick={this.deleteHandler}/>
                        
                    </form>

                </Container>
            </div>
        );
    }
}
