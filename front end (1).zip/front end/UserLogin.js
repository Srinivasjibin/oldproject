import axios from "axios";
import { useState } from "react";
import { Button, Form, Row } from "react-bootstrap";
import { useHistory } from "react-router";
import { Link } from "react-router-dom";

function UserLogin() {
    const [userId, setUserid] = useState("");
    const [password, setPassword] = useState("");
    const History = useHistory();

    const validate = (event) => {
        event.preventDefault();
        axios.post('http://localhost:8080/api/user/getUserPassword',
            {
                "username": userId
            }
        ).then(response => {
            if (password == response.data) {
                window.alert(`logged in successfully`)
                sessionStorage.setItem("userLogged", true);
                sessionStorage.setItem("userId", userId);
                History.push("/userHome")
            }
            else if (response.data == "unavailable") {
                window.alert("Username not present")
            }
            else {
                window.alert(`password not matching`)
            }
        }).catch(error => {
            window.alert("Network error")
            console.log(error, "catch block")
        });

    }
    return (
        <>
            <br /><br /><br /><br />
            <div className="col-sm-4 offset-sm-4 border text-center mt-3">
                <br />
                <h2 className="text-primary m-6">User login</h2><br />
                <form onSubmit={validate}>
                    <input type="text" placeholder="username" className="form-control" onChange={(e) => setUserid(e.target.value)} required /><br />
                    <input type="password" placeholder="password" className="form-control" onChange={(e) => setPassword(e.target.value)} required /><br />
                    <Button type="submit" className="btn  rounded-pill mx-auto  my-3">login </Button>
                </form>
                <Row className="mx-auto">
                    
                    <Form.Row>
                        <Link to="/ResetUserID"><Button className="btn loginBtn rounded-pill ml-3 mr-5 my-4">Forgot Username</Button></Link>
                        <Link to="/ResetUserPassword"><Button className="btn loginBtn rounded-pill ml-5 my-4">Forgot password</Button></Link>
                    </Form.Row>
                </Row>
            </div>
        </>
    )
}
export default UserLogin;