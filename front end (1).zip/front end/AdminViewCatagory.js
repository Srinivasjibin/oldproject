import React, { Component } from "react";
import { Button, Container, Form, Row,Nav, Card, Table } from 'react-bootstrap';
import axios from 'axios';
import AdminNavbar from "./AdminNavbar";

class AdminViewCatagory extends Component {
    constructor(props) {
        super(props);
        if (!sessionStorage.getItem("adminLogged"))
            props.history.push("/")
        this.state = {
            categoryList : [] 
        };
    }
    componentDidMount() {
        axios.get("http://localhost:8080/api/admin/getCategory")
        .then(response => {
            this.setState({categoryList : response.data})
            console.log(response.data)
        })
        
    }
    editIssue(id){
        this.props.history.push("categoryUpdate");
        sessionStorage.setItem("selectedId",id);    
    }
    render(){
        return(
            
            <div>
                <AdminNavbar />
                <Card className={"bg-dark text-white"}>
        
                    <Card.Body className="text-center">
                        <Table variant='dark'>
                            <thead>
                                <tr>
                                    <th>Catagory Id</th>
                                    <th>Catagory type </th>
                                    <th>Catagory Description</th>
                                    
                                </tr>
                            </thead>
                            <tbody>
                                {
                                this.state.categoryList.map((catagory) => (
                                    <tr key = {catagory.categoryId}>
                                      <a onClick={ () => this.editIssue(catagory.categoryId)} style={{cursor: "pointer"}}> 
                                        <td>{catagory.categoryId}</td> </a> 
                                        <td>{catagory.categoryType}</td>
                                        <td>{catagory.categoryDescription}</td>
                                    </tr>
                                ))
                                }
                            </tbody>
                        </Table>
                    </Card.Body>
                </Card>
         
            </div>
        )}
}

export default AdminViewCatagory;