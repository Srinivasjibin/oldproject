import React, { Component } from 'react';
import UserNavbar from './UserNavbar';
import { Button, Container, Form, Row, Nav,Accordion,Card } from 'react-bootstrap';

import axios from 'axios'

class UserHome extends Component {
    constructor(props) {
        super(props)
        if (!sessionStorage.getItem("userLogged"))
            props.history.push("/")
            this.state = {
                issues: [],

            };
    }
    componentWillMount(){
        axios.get('http://localhost:8080/api/admin/getIssueHistory')           
            .then(response => {
                this.setState({ issues : response.data })
                console.log("@log get req Success")
                console.log(response)
            }).catch(error=>console.log("history error"))
    }
    reopenIssue(id){
        this.props.history.push(`/reopenIssue/${id}`);
    }
    render() {
        return (
            <div className="text-center text-white">
                <UserNavbar />
                <Container>
                
                <div className="my-5 mx-auto">
                <h5 className="text-warning">Active Issues</h5>
                {this.state.issues.filter(data=>data.issueStatus=="active").map((el, idx) => {
                    return <div>
                    
                        <Accordion >
                            <Card className="bg-dark" >
                                <Card.Header>
                                    <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                        <p>Notification {idx + 1}</p>
                                    </Accordion.Toggle>
                                </Card.Header>
                                <Accordion.Collapse eventKey="0">
                                    <Card.Body> <div>
                                        <p className="text-light">Issue name:{<br></br>}<span className="p-2 text-danger">{el.issueName}</span></p>
                                        <p className="text-light">Issue Description :{<br></br>}<span className="text-warning">{el.issueDescription}</span></p>
                                        <p className="text-light">Issue Resolution :{<br></br>}<span className="text-warning">{el.issueResolution}</span></p>
                                        <p className="text-light">Issue Category:{<br></br>}<span className="text-warning">{el.issueCategory}</span></p>
                                        <p className="text-light">Issue Created On :{<br></br>}<span className="text-warning">{el.issueDate}</span></p>
                                    </div></Card.Body>
                                </Accordion.Collapse>
                            </Card>
                        </Accordion>
                    </div>
                })}
                <h5 className="text-warning my-2">Resolved Issues</h5>
                 {this.state.issues.filter(data=>data.issueStatus=="completed").map((el, idx) => {
                    return <div>
                 
                        <Accordion >
                            <Card className="bg-dark" >
                                <Card.Header>
                                    <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                        <p>Notification {idx + 1}</p>
                                    </Accordion.Toggle>
                                </Card.Header>
                                <Accordion.Collapse eventKey="0">
                                    <Card.Body> <div>
                                        <p className="text-light">Issue name:{<br></br>}<span className="p-2 text-danger">{el.issueName}</span></p>
                                        <p className="text-light">Issue Description :{<br></br>}<span className="text-warning">{el.issueDescription}</span></p>
                                        <p className="text-light">Issue Resolution :{<br></br>}<span className="text-warning">{el.issueResolution}</span></p>
                                        <p className="text-light">Issue Category:{<br></br>}<span className="text-warning">{el.issueCategory}</span></p>
                                        <p className="text-light">Issue Created On :{<br></br>}<span className="text-warning">{el.issueDate}</span></p>
                                        <Button  onClick={ () => this.reopenIssue(el.id)}>Reopen Issue</Button>
                                    </div></Card.Body>
                                </Accordion.Collapse>
                            </Card>
                        </Accordion>
                    </div>
                })}
                </div>
            </Container>
            </ div>
        );
    }
}

export default UserHome;