import react, { Component } from 'react'
import { Button, Container, Row, Col, Table, Alert, Accordion, Card } from 'react-bootstrap'
import axios from 'axios'
import AdminNavbar from './AdminNavbar';


export default class AdminViewHistory extends Component {
    constructor(props) {
        super(props);
        if (!sessionStorage.getItem("adminLogged"))
            this.props.history.push("/")
        this.state = {
            data: [],
            sortBy: "all"
        };

    }
    componentWillMount() {
        axios.get('http://localhost:8080/api/admin/getIssueHistory')
            .then(response => {
                this.setState({ data: response.data })
                console.log("@log get req Success", response)
            })
        axios.get("http://localhost:8080/api/admin/getCategoryList").then(list => {
            var select = document.getElementById("select");
            for (let type of list.data) {
                let newOp = document.createElement("option");
                newOp.value = type;
                newOp.innerHTML = type;
                select.options.add(newOp);
            }
        }).catch(error =>
            console.log(error)
        )
    };
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value

        })

    }
    editIssue(id) {
        this.props.history.push(`/adminIssueUpdate/${id}`);
    }
    render() {
        let filterData = this.state.sortBy == "all" ?
            this.state.data
            :
            this.state.data.filter(data => data.issueCategory == this.state.sortBy);
        return (
            <div>
                <AdminNavbar />
                <Container className="text-light col-sm-8">
                    <div className="ml-4 text-right">
                        <br />
                        <label >sort by :-</label>
                        <select id="select" name="sortBy" onChange={this.handleChange} >
                            <option>all</option>
                        </select>
                    </div>
                    {filterData.map((issue, idx) => {
                        return <div>
                            <Accordion >
                                <Card className="bg-dark" >
                                    <Card.Header>
                                        <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                            <h5>IssueId {issue.id}</h5>
                                        </Accordion.Toggle>
                                    </Card.Header>
                                    <Accordion.Collapse eventKey="0">
                                        <Card.Body> <div>
                                            <h5>Issue name:{<br />}<span className="p-2 text-danger">{issue.issueName}</span></h5>
                                            <p>Issue Description :{<br></br>}<span className="text-warning">{issue.issueDescription}</span></p>
                                            <p>Issue Resolution :{<br></br>}<span className="text-warning">{issue.issueResolution}</span></p>
                                            <p>Issue Category:{<br></br>}<span className="text-warning">{issue.issueCategory}</span></p>
                                            <p>Issue Status{<br />}<span className="text-warning">{issue.issueStatus}</span></p>
                                            <p>Issue Created On :{<br />}<span className="text-warning">{issue.issueDate}</span>
                                             {issue.issueStatus=="active"||issue.issueStatus=="new" ?  
                                             <span className="text-right offset-5">
                                                    <Button className="ml-5 text-white btn-success" onClick={()=>this.editIssue(issue.id)}>resolve</Button>
                                                </span>:''}
                                            </p>
                                        </div></Card.Body>
                                    </Accordion.Collapse>
                                </Card>
                            </Accordion>
                        </div>
                    })}
                </Container>
            </ div >
        )
    }
}
