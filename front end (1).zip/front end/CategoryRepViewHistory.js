import react, { Component } from 'react'
import { Button, Container, Row, Col, Table, Alert, Accordion, Card } from 'react-bootstrap'
import axios from 'axios'
import CatRepNavBar from './CatRepNavBar';


export default class CategoryRepViewHistory extends Component {
    constructor(props) {
        super(props);
        if (!sessionStorage.getItem("categoryRepLogged"))
            this.props.history.push("/")
        this.state = {
            data: [],
        };
      
    }  
    componentWillMount() {
        axios.get('http://localhost:8080/api/admin/getIssueHistory')
            .then(response => {
                this.setState({ data: response.data })
                console.log("@log get req Success", response)
            })
    };
    handleChange = (event) => {
        this.setState({
            [event.target.name]: event.target.value

        })

    }
    render() {
        let filterData =this.state.data.filter(data=>data.issueCategory==sessionStorage.category);
        return (
            <div>
                <CatRepNavBar />
                <Container className="text-light col-sm-8">
                    {filterData.map((category, idx) => {
                        return <div>
                            <Accordion >
                                <Card className="bg-dark" >
                                    <Card.Header>
                                        <Accordion.Toggle as={Button} variant="link" eventKey="0">
                                            <h5>IssueId {category.id}</h5>
                                        </Accordion.Toggle>
                                    </Card.Header>
                                    <Accordion.Collapse eventKey="0">
                                        <Card.Body> <div>
                                            <h5>Issue name:{<br />}<span className="p-2 text-danger">{category.issueName}</span></h5>
                                            <p>Issue Description :{<br></br>}<span className="text-warning">{category.issueDescription}</span></p>
                                            <p>Issue Resolution :{<br></br>}<span className="text-warning">{category.issueResolution}</span></p>
                                            <p>Issue Category:{<br></br>}<span className="text-warning">{category.issueCategory}</span></p>
                                            <p>Issue Created On :{<br></br>}<span className="text-warning">{category.issueDate}</span></p>
                                        </div></Card.Body>
                                    </Accordion.Collapse>
                                </Card>
                            </Accordion>
                        </div>
                    })}
                </Container>
            </ div >
        )
    }
}
