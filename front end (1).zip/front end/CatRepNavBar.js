import react, { Component } from 'react'
import { Nav } from 'react-bootstrap';
export default class CatRepNavBar extends Component {
    constructor(props) {
        super(props)
    
      }
      logOut = () => {
        sessionStorage.removeItem("categoryRepLogged");
        sessionStorage.removeItem("category");
        window.alert("logged out successfully! ")
        window.location.href = ("/")
      }
  render() {
    return (
      <Nav className="mx-auto navbar bg-dark border border-warning pad">
        <Nav.Item >
          <Nav.Link href="/categoryHome">Home</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href="ViewIssues">New/Active Issues</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link href="/CatRepIssueHistory">Issue History</Nav.Link>
        </Nav.Item>
        <Nav.Item>
          <Nav.Link onClick={this.logOut}>Log Out</Nav.Link>
        </Nav.Item>
      </Nav>
    )
  }
}