import React, { Component } from 'react';
import { BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { Button, Col, Container, ListGroup, Nav, Navbar, NavDropdown, Row } from 'react-bootstrap';
import LoginForm from './LoginForm';

class Home extends Component {
  render() {
    return (
      <>
      
        <Navbar bg="dark" expand="md" variant="dark">
          <Navbar.Brand href="/">Issue Tracker</Navbar.Brand>
          <Navbar.Toggle aria-controls="basic-navbar-nav" />
          <Navbar.Collapse id="basic-navbar-nav">
            <Nav className="mr-auto">
              <Nav.Link href="/">Home</Nav.Link>
              <Nav.Link href="/Register">Register</Nav.Link>
              <NavDropdown title="Login as" id="basic-nav-dropdown">
                <NavDropdown.Item href="userLogin">User</NavDropdown.Item>
                <NavDropdown.Item href="catagoryLogin">Catagory rep</NavDropdown.Item>
              </NavDropdown>
            </Nav>
            <Nav>
              <Nav.Link href="/adminLogin">Admin login</Nav.Link>
            </Nav>
          </Navbar.Collapse>
        </Navbar>
        <div className="text-white text-center mt-5">
          Welcome to Issue tracker application
        </div>
      </>
    );
  }
}

export default Home;