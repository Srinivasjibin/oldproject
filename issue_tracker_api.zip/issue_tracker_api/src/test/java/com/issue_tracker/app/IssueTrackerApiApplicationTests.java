package com.issue_tracker.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IssueTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
